import { Component, OnInit , ViewChild, AfterViewInit, Input, OnChanges } from '@angular/core';
import { MatPaginator, MatTableDataSource, MatSort, MatDialog } from '@angular/material';
import { Observable, merge } from 'rxjs';
import { FormGroup, FormControl, AbstractControl } from '@angular/forms';
import { CommonService } from '../../services/common.service';
import { TableDialogBoxComponent } from '../table-dialog-box/table-dialog-box.component';

class Todo {
  id: string;
  description: string;
  complete: boolean;
}

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss']
})
export class TableComponent implements OnInit, AfterViewInit, OnChanges {

  @Input() tableData: any;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;


  ngOnChanges() {
    console.log(this.tableData);

  }


  constructor(private commonService: CommonService, public dialog: MatDialog) {
    console.log(this.tableData);
    const todos: Todo[] = [
      { id: '123', description: 'Complete sde!', complete: false },
      { id: '123', description: 'Completesfs me!', complete: false },
      { id: '1sdf23', description: 'Complete me!', complete: false },
      { id: '1sf23', description: 'Complete me!', complete: false },
      { id: '1sf23', description: 'Complete me!', complete: false },
      { id: '123', description: 'Complete me!', complete: false },
      { id: '1f23', description: 'Complete me!', complete: false }
    ];
    this.dataSource = new MatTableDataSource(todos);
   }

   form: FormGroup = new FormGroup({
    id: new FormControl(false),
    description: new FormControl(false)
  });


  id = this.form.get('id');
  description = this.form.get('description');
  columnDefinitions = [
    { def: 'id', label: 'ID', hide: this.id.value},
    { def: 'description', label: 'Description', hide: this.description.value}
    // { def: 'action', label: 'action'}
  ];


  getDisplayedColumns(): string[] {
    return this.columnDefinitions.filter(cd => !cd.hide).map(cd => cd.def);
  }

  // openDialog(action, obj) {
  //   obj.action = action;
  //   const dialogRef = this.dialog.open(TableDialogBoxComponent, {
  //     width: '250px',
  //     data: obj
  //   });

  //   dialogRef.afterClosed().subscribe(result => {
  //     if(result.event == 'Add'){
  //       this.addRowData(result.data);
  //     }else if(result.event == 'Update'){
  //       this.updateRowData(result.data);
  //     }else if(result.event == 'Delete'){
  //       this.deleteRowData(result.data);
  //     }
  //   });
  // }

  // addRowData(row_obj){
  //   this.dataSource.push({
  //     id: '',
  //     name: row_obj.name
  //   });
  //   // this.table.renderRows();

  // }
  // updateRowData(row_obj){
  //   this.dataSource = this.dataSource.filter((value,key)=>{
  //     if(value.id == row_obj.id){
  //       value.name = row_obj.name;
  //     }
  //     return true;
  //   });
  // }
  // deleteRowData(row_obj){
  //   this.dataSource = this.dataSource.filter((value,key)=>{
  //     return value.id != row_obj.id;
  //   });
  // }


  // tslint:disable-next-line: member-ordering
  dataSource: MatTableDataSource<any>;

  ngAfterViewInit() {
   const o1: Observable<boolean> = this.id.valueChanges;
   const o2: Observable<boolean> = this.description.valueChanges;

   merge(o1, o2).subscribe( v => {
   this.columnDefinitions[0].hide = this.id.value;
   this.columnDefinitions[1].hide = this.description.value;
    });
  }


  ngOnInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  public doFilter = (value: string) => {
    this.dataSource.filter = value.trim().toLocaleLowerCase();
    this.commonService.openSnackBar('filter', 'close');
  }

}
